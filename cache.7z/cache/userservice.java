package com.baidu.adgameoperate.cache;


import java.util.Map;

/**
 * Created by Administrator on 2018/1/11.
 */
public interface userservice {

    public abstract void add(User user);

    public abstract void delete(String id);

  public abstract void update(User user);

 public abstract User find(String id);

  public abstract Map<String, User> getAll();



}
