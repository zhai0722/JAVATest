package com.baidu.adgameoperate.cache;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Map;

/**
 * Created by Administrator on 2018/1/11.
 */
public class MainTest {

    public static void main(String[] args) {


    ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring-cache.xml");
    userservice  userService = context.getBean("userService", userservice.class);
        System.out.println("service bean: " + userService);
        userService.add(new User("1", "Ilucky1", "pwd1"));
        userService.add(new User("2", "Ilucky2", "pwd2"));
        userService.add(new User("3", "Ilucky3", "pwd3"));
        Map<String, User> map = userService.getAll();
        for(Map.Entry<String, User> entry : map.entrySet()) {
          System.out.println(entry.getValue());
             }

        Map<String, User> map2 = userService.getAll();
      for(Map.Entry<String, User> entry : map2.entrySet()) {
            System.out.println(entry.getValue());
           }
        userService.update(new User("1", "Ilucky1_new", "pwd1_new"));
        Map<String, User> map3 = userService.getAll();
         for(Map.Entry<String, User> entry : map3.entrySet()) {
               System.out.println(entry.getValue());
          }


    }

}
