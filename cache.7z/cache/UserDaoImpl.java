package com.baidu.adgameoperate.cache;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2018/1/11.
 */
public class UserDaoImpl implements  UserDao{

    //使用Map模拟数据表.
  private Map<String, User> users = new HashMap<String, User>();

    @Override
    public void add(User user) {
        System.out.println("userdao add user");
        users.put( user.getId(), user);
    }

    @Override
    public void delete(String id) {
        System.out.println("userdao delete user ");
        users.remove(id);

    }

    @Override
    public void update(User user) {
        System.out.println("userdao update user");
        users.put(user.getId(),user);
    }

    @Override
    public User find(String id) {
        System.out.println("userdao find");
        return users.get(id);
    }

    @Override
    public Map<String, User> getAll() {
        System.out.println("userdao getall");
        return users;
    }
}
