package com.baidu.adgameoperate.cache;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;

import java.util.Map;

/**
 * Created by Administrator on 2018/1/11.
 */
public class userserviceImpl implements  userservice {
    private  UserDao userDao;
    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }



    @Override
    @CacheEvict(value = "data", allEntries = true)
    public void add(User user) {
        System.out.println("userservice:add user");
        userDao.add(user);
    }

    @Override
    @CacheEvict(value = "data", allEntries = true)
    public void delete(String id) {
        System.out.println("userservice:delete user");
        userDao.delete(id);
    }

    @Override
    @CacheEvict(value = "data", allEntries = true)
    public void update(User user) {
        System.out.println("userservice:update user");
        userDao.update(user);
    }

    @Override
    @Cacheable(value = "data")
    public User find(String id) {
        System.out.println("userservice:find user");
        return userDao.find(id);
    }

    @Override
    @Cacheable(value = "data")
    public Map<String, User> getAll() {
        System.out.println("userservice:getAll user");
        return userDao.getAll();
    }
}
